<h1>Doc file</h1>
<!-- admin/partials/docs.php -->
<?php if (!defined('ABSPATH')) exit; ?>
<div class="wrap">
  <h1><?php esc_html_e('DevTeamPro Documentation', 'devteampro-dotnet-wp'); ?></h1>